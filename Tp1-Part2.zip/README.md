# Autores:
- Gomez Luis (lgomez@patagones.cl)
- Iriarte Nicolás (NicolasIriarte95@gmail.com)
- Edda Andrade Rosales (edda.geraldine.andrade.rosales@gmail.com) desde TP1 B y TP2 A

# Otros:
Podrá encontrar el enunciado comple [aqui](assets/D05_TP1_ParteB_v0p1.pdf)
